"""بيانات تسجيل النطاق (WHOIS) عبر بروتوكول RDAP الحديث: تاريخ التسجيل، المسجِّل، وبريد البلاغات."""
from datetime import datetime, timezone
from functools import lru_cache

import requests


@lru_cache(maxsize=2048)
def lookup(domain: str):
    out = {"domain": domain, "created": None, "age_days": None, "registrar": None, "abuse_email": None, "source": None}
    try:
        r = requests.get(f"https://rdap.org/domain/{domain}", timeout=10, headers={"Accept": "application/rdap+json"})
        if r.status_code == 200:
            data = r.json()
            out["source"] = "rdap"
            for ev in data.get("events", []):
                if ev.get("eventAction") == "registration":
                    out["created"] = ev.get("eventDate")
            for ent in data.get("entities", []):
                roles = ent.get("roles", [])
                if "registrar" in roles:
                    out["registrar"] = _vcard(ent, "fn")
                    for sub in ent.get("entities", []):
                        if "abuse" in sub.get("roles", []):
                            out["abuse_email"] = _vcard(sub, "email")
                if "abuse" in roles and not out["abuse_email"]:
                    out["abuse_email"] = _vcard(ent, "email")
    except Exception:
        pass
    if not out["created"]:
        # بديل: مكتبة python-whois إن كانت مثبتة
        try:
            import whois
            w = whois.whois(domain)
            c = w.creation_date[0] if isinstance(w.creation_date, list) else w.creation_date
            if c:
                out["created"] = c.replace(tzinfo=timezone.utc).isoformat()
                out["registrar"] = out["registrar"] or w.registrar
                out["source"] = "whois"
        except Exception:
            pass
    if out["created"]:
        try:
            dt = datetime.fromisoformat(out["created"].replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            out["age_days"] = (datetime.now(timezone.utc) - dt).days
        except Exception:
            pass
    return out


def _vcard(ent, field):
    try:
        for item in ent["vcardArray"][1]:
            if item[0] == field:
                return item[3]
    except Exception:
        return None
    return None
