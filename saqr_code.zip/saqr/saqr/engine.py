"""
محرك صقر: يستقبل رابطاً ويرجع درجة خطر من 100 مع الأسباب والأدلة.
الطبقات: تتبّع الرابط ← تحليل العنوان ← بيانات النطاق ← المحتوى ← التشابه البصري ← تتبّع المال ← القرار.
"""
import os
import uuid
from datetime import datetime, timezone

from . import content as content_mod
from . import fetch as fetch_mod
from . import lexical, money, rdap, visual
from .brands import BRANDS
from .domain import host_of, normalize_url, registered_domain, whitelist_match

try:
    import joblib
except Exception:
    joblib = None

BASE = os.path.join(os.path.dirname(__file__), "..")
MODEL_PATH = os.path.join(BASE, "model", "model.joblib")
SHOTS_DIR = os.path.join(BASE, "evidence", "screenshots")
_MODEL = None


def _model():
    global _MODEL
    if _MODEL is None and joblib and os.path.exists(MODEL_PATH):
        try:
            _MODEL = joblib.load(MODEL_PATH)
        except Exception:
            _MODEL = False
    return _MODEL or None


class Reasons:
    def __init__(self):
        self.items = []
        self.points = 0

    def add(self, pts, text, layer):
        self.points += pts
        self.items.append({"points": pts, "text": text, "layer": layer})


def level_of(score):
    if score >= 70:
        return "high", "خطورة عالية"
    if score >= 40:
        return "medium", "مشبوه"
    return "low", "خطورة منخفضة"


def scan(url: str, source: str = "manual", fetch: bool = True, deep: bool = True) -> dict:
    """
    fetch=False: تحليل العنوان فقط (سريع، بدون إنترنت).
    deep=True: يضيف بيانات النطاق، كشف الإخفاء، لقطة الشاشة، والنموذج اللغوي إن توفر.
    """
    url = normalize_url(url)
    started = datetime.now(timezone.utc)
    R = Reasons()
    res = {
        "id": uuid.uuid4().hex[:12], "input_url": url, "source": source,
        "scanned_at": started.isoformat(timespec="seconds"),
    }

    # ---------- 1) تتبّع الرابط ----------
    final_url, page = url, None
    if fetch:
        page = fetch_mod.follow(url)
        final_url = page["final_url"]
        res["redirect_chain"] = page["chain"]
        res["http_status"] = page["status"]
        res["html_sha256"] = page["html_sha256"]
        hops = len(page["chain"]) - 1
        if hops >= 1 and registered_domain(host_of(final_url)) != registered_domain(host_of(url)):
            R.add(5, f"الرابط يحوّل إلى نطاق آخر بعد {hops} خطوة إعادة توجيه", "تتبّع الرابط")
        if hops >= 3:
            R.add(5, f"سلسلة إعادة توجيه طويلة ({hops} خطوات)", "تتبّع الرابط")
    res["final_url"] = final_url
    host = host_of(final_url)
    res["domain"] = host
    res["registered_domain"] = registered_domain(host)

    # ---------- القائمة البيضاء ----------
    wl = whitelist_match(host)
    if wl:
        res.update({"score": 0, "level": "safe", "level_ar": "موقع رسمي / موثوق",
                    "reasons": [{"points": 0, "text": f"نطاق موثوق ضمن القائمة البيضاء ({wl if wl != 'safe' else 'موقع عالمي معروف'})",
                                 "layer": "القائمة البيضاء"}],
                    "whitelisted": True, "indicators": {}, "uae_targeted": wl != "safe"})
        return res

    # ---------- 2) تحليل العنوان ----------
    f = lexical.extract(final_url)
    orig_f = lexical.extract(url)
    if orig_f["is_shortener"] and final_url != url:
        R.add(5, "رابط مختصر يخفي العنوان الحقيقي", "تحليل العنوان")
    impersonated = []
    for b, kind, detail in f["_brand_hits"]:
        impersonated.append(b)
        if kind == "keyword":
            R.add(35, f"يستخدم اسم «{b['name_ar']}» في نطاق غير رسمي", "تحليل العنوان")
        elif kind == "typo":
            R.add(35, f"اسم النطاق قريب جداً من النطاق الرسمي {detail} (تحريف مقصود)", "تحليل العنوان")
        elif kind == "tld_swap":
            R.add(30, f"نفس اسم {detail} لكن بامتداد مختلف", "تحليل العنوان")
    if impersonated and (f["_sus_words"] or f["risky_tld"]):
        R.add(10, "انتحال جهة إماراتية مع كلمات دفع أو تحقق: نمط احتيال معروف", "تحليل العنوان")
    if f["has_ip"]:
        R.add(20, "الرابط يستخدم عنوان IP بدل اسم نطاق", "تحليل العنوان")
    if f["has_punycode"]:
        R.add(20, "النطاق يستخدم أحرفاً مشابهة من لغات أخرى (Punycode)", "تحليل العنوان")
    if f["risky_tld"]:
        R.add(10, f"امتداد نطاق يكثر استخدامه في الاحتيال (.{f['_suffix'].split('.')[-1]})", "تحليل العنوان")
    if f["_sus_words"]:
        R.add(min(16, 8 * len(f["_sus_words"])), "كلمات احتيال شائعة في الرابط: " + "، ".join(f["_sus_words"][:4]), "تحليل العنوان")
    if f["n_subdomains"] >= 3 or f["n_hyphens"] >= 3:
        R.add(5, "بنية نطاق معقدة (نطاقات فرعية أو شرطات كثيرة)", "تحليل العنوان")
    if f["has_at"]:
        R.add(10, "الرابط يحتوي @ لإخفاء الوجهة الحقيقية", "تحليل العنوان")
    if not f["is_https"] and fetch:
        R.add(5, "الموقع لا يستخدم اتصالاً مشفراً HTTPS", "تحليل العنوان")

    # ---------- 3) بيانات النطاق ----------
    res["ip"] = fetch_mod.resolve_ip(host) if fetch else None
    if fetch and deep and not f["has_ip"]:
        w = rdap.lookup(res["registered_domain"])
        res["whois"] = w
        age = w.get("age_days")
        if age is not None:
            if age < 30:
                R.add(25, f"النطاق مسجَّل منذ {age} يوماً فقط", "بيانات النطاق")
            elif age < 180:
                R.add(10, f"النطاق حديث ({age} يوماً)", "بيانات النطاق")

    # ---------- 4) المحتوى ----------
    indicators = {}
    uae_score = 1 if impersonated else 0
    if page and page.get("html"):
        c = content_mod.analyze(page["html"], final_url)
        res["page_title"] = c.get("title")
        page_brands = [b for b in c.get("brands", []) if b not in impersonated]
        if (c["has_password"] or c["has_card"] or c["has_otp"] or c["has_id"]):
            asked = [n for k, n in (("has_password", "كلمة المرور"), ("has_card", "بيانات البطاقة"),
                                    ("has_otp", "رمز التحقق"), ("has_id", "رقم الهوية")) if c[k]]
            if c["brands"]:
                R.add(25, f"صفحة تذكر «{c['brands'][0]['name_ar']}» وتطلب: " + "، ".join(asked), "قراءة المحتوى")
            else:
                R.add(10, "الصفحة تطلب: " + "، ".join(asked), "قراءة المحتوى")
        elif page_brands:
            R.add(10, f"الصفحة تذكر «{page_brands[0]['name_ar']}» من نطاق غير رسمي", "قراءة المحتوى")
        if c["external_forms"]:
            R.add(15, "النموذج يرسل البيانات إلى نطاق مختلف", "قراءة المحتوى")
        if c["urgency"]:
            R.add(10, "عبارات استعجال وتهديد: " + "، ".join(c["urgency"][:3]), "قراءة المحتوى")
        if c.get("uae_markers", 0) >= 2 or c.get("brands"):
            uae_score += 1
        impersonated += [b for b in c.get("brands", []) if b not in impersonated]

        indicators = money.extract(page["html"] + " " + c.get("text", ""))
        if money.has_any(indicators):
            parts = []
            if indicators["ibans"]:
                parts.append(f"{len(indicators['ibans'])} حساب IBAN")
            if indicators["phones"]:
                parts.append(f"{len(indicators['phones'])} رقم هاتف")
            if indicators["wallets"]:
                parts.append(f"{len(indicators['wallets'])} محفظة رقمية")
            if indicators["telegram"]:
                parts.append("حساب تيليجرام")
            R.add(5, "استُخرج من الصفحة: " + "، ".join(parts), "تتبّع المال")

        if deep:
            ck = fetch_mod.cloaking_check(url, page)
            res["cloaking"] = ck
            if ck and ck["suspicious"]:
                R.add(15, "الموقع يعرض محتوى مختلفاً لأنظمة الفحص عن المستخدمين (إخفاء)", "تتبّع الرابط")

            llm = content_mod.llm_review(c.get("title", ""), c.get("text", ""), final_url)
            res["llm"] = llm
            if llm and llm.get("is_scam") and llm.get("confidence", 0) >= 60:
                R.add(20, "النموذج اللغوي: " + (llm.get("reason_ar") or "الصفحة احتيالية"), "قراءة المحتوى")

    # ---------- 5) التشابه البصري ----------
    if fetch and deep and page and page.get("html"):
        os.makedirs(SHOTS_DIR, exist_ok=True)
        shot = os.path.join(SHOTS_DIR, f"{res['id']}.png")
        if fetch_mod.screenshot(final_url, shot):
            res["screenshot"] = shot
            v = visual.compare(shot)
            res["visual"] = v
            if v and v["score"] >= 80:
                b = next((x for x in BRANDS if x["id"] == v["brand_id"]), None)
                name = b["name_ar"] if b else v["brand_id"]
                R.add(30, f"شكل الصفحة يطابق موقع «{name}» بنسبة {v['score']}% لكن من نطاق غير رسمي", "التشابه البصري")
                uae_score += 1

    # ---------- 6) القرار ----------
    rule_score = min(100, R.points)
    ml_prob = None
    m = _model()
    if m is not None:
        try:
            ml_prob = float(m.predict_proba([lexical.host_vector(final_url)])[0][1])
        except Exception:
            ml_prob = None
    if ml_prob is not None:
        # النموذج يرفع الدرجة فقط ولا يخفضها: القواعد هي مصدر الأسباب المكتوبة
        score = max(rule_score, round(0.6 * rule_score + 0.4 * ml_prob * 100))
        if ml_prob >= 0.5:
            R.items.append({"points": 0, "text": f"نموذج التصنيف المدرّب يقدّر احتمال الاحتيال بـ {round(ml_prob * 100)}%", "layer": "القرار"})
    else:
        score = rule_score
    lvl, lvl_ar = level_of(score)
    if impersonated:
        uae_score += 1
    res.update({
        "score": int(score), "level": lvl, "level_ar": lvl_ar,
        "rule_score": rule_score, "ml_probability": ml_prob,
        "reasons": sorted(R.items, key=lambda x: -x["points"]),
        "impersonated": [b["name_ar"] for b in impersonated][:3],
        "indicators": indicators,
        "uae_targeted": uae_score >= 1,
        "whitelisted": False,
        "duration_ms": int((datetime.now(timezone.utc) - started).total_seconds() * 1000),
    })
    return res
