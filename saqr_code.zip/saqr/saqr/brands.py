"""
قائمة الجهات الإماراتية التي يحميها صقر.
كل جهة: اسمها، نطاقاتها الرسمية (القائمة البيضاء)، والكلمات التي يستخدمها المحتالون لانتحالها.
راجعوا النطاقات الرسمية وأضيفوا ما ينقص قبل العرض.
"""

BRANDS = [
    {"id": "adpolice", "name_ar": "شرطة أبوظبي", "name_en": "Abu Dhabi Police",
     "official": ["adpolice.gov.ae"],
     "keywords": ["adpolice", "adpolic", "abudhabipolice", "ad-police", "شرطة أبوظبي", "شرطة ابوظبي"]},
    {"id": "dubaipolice", "name_ar": "شرطة دبي", "name_en": "Dubai Police",
     "official": ["dubaipolice.gov.ae"],
     "keywords": ["dubaipolice", "dubai-police", "شرطة دبي"]},
    {"id": "moi", "name_ar": "وزارة الداخلية", "name_en": "Ministry of Interior",
     "official": ["moi.gov.ae"],
     "keywords": ["moi-uae", "uaemoi", "moigov", "وزارة الداخلية"]},
    {"id": "uaepass", "name_ar": "الهوية الرقمية UAE PASS", "name_en": "UAE PASS",
     "official": ["uaepass.ae"],
     "keywords": ["uaepass", "uae-pass", "uaepas", "الهوية الرقمية"]},
    {"id": "tamm", "name_ar": "تطبيق تم", "name_en": "TAMM",
     "official": ["tamm.abudhabi", "abudhabi.gov.ae"],
     "keywords": ["tamm", "تم أبوظبي"]},
    {"id": "uaegov", "name_ar": "البوابة الرسمية لحكومة الإمارات", "name_en": "UAE Government Portal",
     "official": ["u.ae"],
     "keywords": ["uaegov", "uae-gov", "govuae"]},
    {"id": "icp", "name_ar": "الهيئة الاتحادية للهوية والجنسية", "name_en": "ICP",
     "official": ["icp.gov.ae"],
     "keywords": ["icp-uae", "icpuae", "emiratesid", "emirates-id", "الهوية والجنسية"]},
    {"id": "rta", "name_ar": "هيئة الطرق والمواصلات", "name_en": "RTA",
     "official": ["rta.ae"],
     "keywords": ["rta-dubai", "rtadubai", "rta-fines", "هيئة الطرق"]},
    {"id": "salik", "name_ar": "سالك", "name_en": "Salik",
     "official": ["salik.ae"],
     "keywords": ["salik", "سالك"]},
    {"id": "fines", "name_ar": "سداد المخالفات المرورية", "name_en": "Traffic fines",
     "official": [],
     "keywords": ["mukhalafat", "traffic-fine", "trafficfine", "uaefines", "fines-uae", "pay-fine", "المخالفات المرورية", "سداد المخالفات"]},
    {"id": "adcb", "name_ar": "بنك أبوظبي التجاري", "name_en": "ADCB",
     "official": ["adcb.com"],
     "keywords": ["adcb", "بنك أبوظبي التجاري"]},
    {"id": "fab", "name_ar": "بنك أبوظبي الأول", "name_en": "First Abu Dhabi Bank",
     "official": ["bankfab.com"],
     "keywords": ["bankfab", "fab-bank", "fabbank", "بنك أبوظبي الأول"]},
    {"id": "enbd", "name_ar": "بنك الإمارات دبي الوطني", "name_en": "Emirates NBD",
     "official": ["emiratesnbd.com"],
     "keywords": ["emiratesnbd", "emirates-nbd", "enbd", "الإمارات دبي الوطني"]},
    {"id": "adib", "name_ar": "مصرف أبوظبي الإسلامي", "name_en": "ADIB",
     "official": ["adib.ae"],
     "keywords": ["adib", "مصرف أبوظبي الإسلامي"]},
    {"id": "dib", "name_ar": "بنك دبي الإسلامي", "name_en": "Dubai Islamic Bank",
     "official": ["dib.ae"],
     "keywords": ["dubaiislamic", "dib-bank", "بنك دبي الإسلامي"]},
    {"id": "mashreq", "name_ar": "بنك المشرق", "name_en": "Mashreq",
     "official": ["mashreq.com"],
     "keywords": ["mashreq", "المشرق"]},
    {"id": "etisalat", "name_ar": "اتصالات e&", "name_en": "e& (Etisalat)",
     "official": ["etisalat.ae", "eand.com", "eand.ae"],
     "keywords": ["etisalat", "اتصالات"]},
    {"id": "du", "name_ar": "دو", "name_en": "du",
     "official": ["du.ae"],
     "keywords": ["du-telecom", "du-uae", "dutelecom"]},
    {"id": "emiratespost", "name_ar": "بريد الإمارات", "name_en": "Emirates Post",
     "official": ["emiratespost.ae"],
     "keywords": ["emiratespost", "emirates-post", "epg-uae", "بريد الإمارات"]},
    {"id": "aramex", "name_ar": "أرامكس", "name_en": "Aramex",
     "official": ["aramex.com"],
     "keywords": ["aramex", "أرامكس"]},
    {"id": "emirates", "name_ar": "طيران الإمارات", "name_en": "Emirates airline",
     "official": ["emirates.com"],
     "keywords": ["emirates-air", "emiratesairline", "fly-emirates"]},
]

# مواقع عالمية سليمة شائعة، حتى لا تُصنَّف خطأً. يمكن توسيعها بقائمة Tranco عبر data/tranco.csv
GLOBAL_SAFE = [
    "google.com", "youtube.com", "facebook.com", "instagram.com", "whatsapp.com", "x.com",
    "twitter.com", "linkedin.com", "microsoft.com", "apple.com", "icloud.com", "amazon.com",
    "amazon.ae", "noon.com", "wikipedia.org", "github.com", "gov.ae",
]

# مختصرات الروابط الشائعة
SHORTENERS = [
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "ow.ly", "cutt.ly", "rb.gy", "s.id",
    "shorturl.at", "rebrand.ly", "t.ly", "v.gd", "tiny.cc", "lnkd.in", "buff.ly", "short.gy",
]

RISKY_TLDS = [
    "xyz", "top", "icu", "shop", "click", "live", "online", "site", "buzz", "cfd", "sbs", "rest",
    "vip", "monster", "quest", "cyou", "work", "support", "help", "info", "win", "loan", "bond",
    "lol", "mom", "pw", "tk", "ml", "ga", "cf", "gq",
]


def all_official_domains():
    out = []
    for b in BRANDS:
        out.extend(b["official"])
    return out
