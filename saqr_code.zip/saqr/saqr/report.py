"""
مخرجات الشرطة: تقرير أدلة (HTML جاهز للطباعة PDF من المتصفح) وطلب إزالة بالإنجليزية للمستضيف والمسجِّل.
"""
import base64
import html
import os


def _e(x):
    return html.escape(str(x if x is not None else "—"))


def evidence_html(r: dict) -> str:
    shot = ""
    if r.get("screenshot") and os.path.exists(r["screenshot"]):
        with open(r["screenshot"], "rb") as f:
            shot = f'<img src="data:image/png;base64,{base64.b64encode(f.read()).decode()}" style="width:100%;border:1px solid #ccc;border-radius:8px">'
    w = r.get("whois") or {}
    ind = r.get("indicators") or {}
    reasons = "".join(f"<li>{_e(x['text'])} <span class='pts'>(+{x['points']})</span></li>" for x in r.get("reasons", []))
    chain = "".join(f"<li dir='ltr'>{_e(c.get('status'))} — {_e(c.get('url'))}</li>" for c in r.get("redirect_chain", []))
    def lst(k):
        v = ind.get(k) or []
        return "<br>".join(f"<span dir='ltr'>{_e(x)}</span>" for x in v) or "—"
    color = {"high": "#B4232A", "medium": "#B76E00", "low": "#2F6B3A", "safe": "#2F6B3A"}.get(r.get("level"), "#333")
    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>تقرير أدلة صقر — {_e(r.get('domain'))}</title>
<style>
body{{font-family:Tahoma,Arial,sans-serif;max-width:900px;margin:32px auto;color:#1B2733;line-height:1.7}}
h1{{margin:0}} .muted{{color:#5F6873}} table{{width:100%;border-collapse:collapse;margin:12px 0}}
td,th{{border:1px solid #ddd;padding:8px;text-align:right;vertical-align:top}} th{{background:#F3EEE4;width:30%}}
.score{{font-size:48px;font-weight:bold;color:{color}}} .pts{{color:#888;font-size:12px}}
.box{{border:2px solid {color};border-radius:10px;padding:16px;margin:16px 0}}
@media print{{body{{margin:0}}}}
</style></head><body>
<h1>صقر — تقرير أدلة</h1>
<p class="muted">رقم الفحص {_e(r.get('id'))} · وقت الفحص (UTC) {_e(r.get('scanned_at'))} · المصدر {_e(r.get('source'))}</p>
<div class="box"><span class="score">{_e(r.get('score'))}/100</span> &nbsp; <b style="color:{color}">{_e(r.get('level_ar'))}</b>
<p>الجهة المنتحَلة: {_e('، '.join(r.get('impersonated') or []) or '—')}</p></div>
<h2>أسباب الحكم</h2><ol>{reasons}</ol>
<h2>بيانات الموقع</h2><table>
<tr><th>الرابط المُدخل</th><td dir="ltr">{_e(r.get('input_url'))}</td></tr>
<tr><th>الوجهة النهائية</th><td dir="ltr">{_e(r.get('final_url'))}</td></tr>
<tr><th>النطاق المسجَّل</th><td dir="ltr">{_e(r.get('registered_domain'))}</td></tr>
<tr><th>عنوان IP</th><td dir="ltr">{_e(r.get('ip'))}</td></tr>
<tr><th>تاريخ تسجيل النطاق</th><td dir="ltr">{_e(w.get('created'))} ({_e(w.get('age_days'))} يوم)</td></tr>
<tr><th>المسجِّل</th><td dir="ltr">{_e(w.get('registrar'))}</td></tr>
<tr><th>بريد البلاغات</th><td dir="ltr">{_e(w.get('abuse_email'))}</td></tr>
<tr><th>عنوان الصفحة</th><td>{_e(r.get('page_title'))}</td></tr>
<tr><th>بصمة الصفحة SHA-256</th><td dir="ltr" style="font-size:12px">{_e(r.get('html_sha256'))}</td></tr>
</table>
<h2>سلسلة إعادة التوجيه</h2><ol>{chain or '<li>—</li>'}</ol>
<h2>تتبّع المال</h2><table>
<tr><th>حسابات IBAN</th><td>{lst('ibans')}</td></tr>
<tr><th>أرقام هواتف</th><td>{lst('phones')}</td></tr>
<tr><th>محافظ رقمية</th><td>{lst('wallets')}</td></tr>
<tr><th>تيليجرام</th><td>{lst('telegram')}</td></tr></table>
<h2>لقطة الشاشة</h2>{shot or '<p class="muted">لا توجد لقطة</p>'}
<p class="muted">أُنشئ هذا التقرير آلياً بواسطة صقر. القرار النهائي بالإجراء يعود للمختص في الشرطة.</p>
</body></html>"""


def takedown_text(r: dict) -> str:
    w = r.get("whois") or {}
    imp = ", ".join(r.get("impersonated") or []) or "a UAE organisation"
    reasons = "\n".join(f"  - {x['text']}" for x in r.get("reasons", [])[:6])
    return f"""To: {w.get('abuse_email') or '[abuse contact of hosting provider / registrar]'}
Subject: Urgent takedown request – phishing site impersonating a UAE entity – {r.get('registered_domain')}

Dear Abuse Team,

We are reporting an active phishing website targeting residents of the United Arab Emirates.

  Domain:        {r.get('registered_domain')}
  URL:           {r.get('final_url')}
  IP address:    {r.get('ip') or 'n/a'}
  Registrar:     {w.get('registrar') or 'n/a'}
  Registered on: {w.get('created') or 'n/a'}
  Detected (UTC): {r.get('scanned_at')}
  Risk score:    {r.get('score')}/100
  Impersonating: {imp}
  Page SHA-256:  {r.get('html_sha256') or 'n/a'}

Detection reasons (Arabic, from our automated analysis):
{reasons}

We request that you suspend this domain/hosting and preserve all related logs and account data
for a possible law-enforcement request. Evidence (screenshot, redirect chain, page hash) is attached.

Reference: SAQR-{r.get('id')}
[Officer name / unit / contact]
"""
