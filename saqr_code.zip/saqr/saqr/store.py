"""حفظ نتائج الفحص في قاعدة بيانات SQLite محلية."""
import json
import os
import sqlite3

DB = os.path.join(os.path.dirname(__file__), "..", "evidence", "saqr.db")


def _conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS scans(
        id TEXT PRIMARY KEY, scanned_at TEXT, source TEXT, input_url TEXT, final_url TEXT,
        domain TEXT, registered_domain TEXT, ip TEXT, score INTEGER, level TEXT, uae_targeted INTEGER,
        data TEXT)""")
    return c


def save(r: dict):
    with _conn() as c:
        slim = {k: v for k, v in r.items() if k != "html"}
        c.execute("INSERT OR REPLACE INTO scans VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (
            r["id"], r["scanned_at"], r.get("source"), r["input_url"], r.get("final_url"), r.get("domain"),
            r.get("registered_domain"), r.get("ip"), r.get("score", 0), r.get("level"),
            int(bool(r.get("uae_targeted"))), json.dumps(slim, ensure_ascii=False, default=str)))


def all_scans(min_score: int = 0, limit: int = 2000):
    with _conn() as c:
        rows = c.execute("SELECT data FROM scans WHERE score >= ? ORDER BY score DESC, scanned_at DESC LIMIT ?",
                         (min_score, limit)).fetchall()
    return [json.loads(r[0]) for r in rows]


def seen(domain: str) -> bool:
    with _conn() as c:
        return c.execute("SELECT 1 FROM scans WHERE registered_domain=? LIMIT 1", (domain,)).fetchone() is not None
