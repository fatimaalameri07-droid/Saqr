"""تحليل النطاق: استخراج النطاق المسجَّل، القائمة البيضاء، وقياس التشابه مع النطاقات الرسمية."""
import ipaddress
import os
from urllib.parse import urlparse

from .brands import BRANDS, GLOBAL_SAFE, all_official_domains

try:
    import tldextract  # اختياري: أدق في تحديد النطاق المسجَّل
    _TLDX = tldextract.TLDExtract(suffix_list_urls=())
except Exception:
    _TLDX = None

# لاحقات متعددة الأجزاء الأكثر شيوعاً (تُستخدم إذا لم تتوفر tldextract)
MULTI_SUFFIXES = {
    "gov.ae", "ac.ae", "co.ae", "net.ae", "org.ae", "sch.ae", "mil.ae",
    "co.uk", "org.uk", "gov.uk", "ac.uk", "com.au", "com.sa", "gov.sa", "com.eg",
    "com.br", "co.in", "co.jp", "com.tr", "com.cn", "com.pk", "com.qa", "com.kw", "com.om", "com.bh",
}

HOMOGLYPHS = {"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "@": "a", "$": "s"}
HOMOGLYPH_SEQS = {"rn": "m", "vv": "w", "cl": "d", "ii": "u"}


def normalize_url(url: str) -> str:
    url = (url or "").strip().strip("<>\"'")
    # روابط "منزوعة الخطورة" مثل hxxp و [.]
    url = url.replace("hxxps://", "https://").replace("hxxp://", "http://").replace("[.]", ".").replace("(.)", ".")
    if not url.lower().startswith(("http://", "https://")):
        url = "http://" + url
    return url


def host_of(url: str) -> str:
    host = (urlparse(normalize_url(url)).hostname or "").lower().rstrip(".")
    return host


def is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def split_domain(host: str):
    """يرجع (subdomain, sld, suffix). مثال: login.adcb-secure.co.ae -> (login, adcb-secure, co.ae)"""
    host = host.lower().rstrip(".")
    if is_ip(host):
        return "", host, ""
    if _TLDX is not None:
        r = _TLDX(host)
        if r.suffix:
            return r.subdomain, r.domain, r.suffix
    labels = host.split(".")
    if len(labels) == 1:
        return "", labels[0], ""
    last2 = ".".join(labels[-2:])
    if last2 in MULTI_SUFFIXES and len(labels) >= 3:
        return ".".join(labels[:-3]), labels[-3], last2
    return ".".join(labels[:-2]), labels[-2], labels[-1]


def registered_domain(host: str) -> str:
    sub, sld, suf = split_domain(host)
    return f"{sld}.{suf}" if suf else sld


def _load_tranco(limit=50000):
    path = os.path.join(os.path.dirname(__file__), "..", "data", "tranco.csv")
    out = set()
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for i, line in enumerate(f):
                if i >= limit:
                    break
                parts = line.strip().split(",")
                if parts:
                    out.add(parts[-1].lower())
    return out


_OFFICIAL = set(all_official_domains())
_SAFE = set(GLOBAL_SAFE) | _load_tranco()


def whitelist_match(host: str):
    """يرجع اسم الجهة إذا كان النطاق رسمياً، أو 'safe' إذا كان موقعاً عالمياً معروفاً، أو None."""
    host = host.lower()
    for b in BRANDS:
        for off in b["official"]:
            if host == off or host.endswith("." + off):
                return b["name_ar"]
    reg = registered_domain(host)
    if reg in _SAFE or host in _SAFE:
        return "safe"
    # أي نطاق حكومي إماراتي رسمي
    if host.endswith(".gov.ae"):
        return "جهة حكومية إماراتية"
    return None


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def deglyph(s: str) -> str:
    s = s.lower()
    for k, v in HOMOGLYPH_SEQS.items():
        s = s.replace(k, v)
    return "".join(HOMOGLYPHS.get(c, c) for c in s)


def brand_similarity(host: str):
    """
    يبحث عن أقرب نطاق رسمي للنطاق المفحوص.
    يرجع قائمة نتائج: كل نتيجة (brand, نوع التشابه, تفاصيل)
    """
    host = host.lower()
    sub, sld, suf = split_domain(host)
    full_labels = host.replace("-", ".").split(".")
    flat = host.replace(".", "").replace("-", "")
    hits = []
    for b in BRANDS:
        # 1) كلمة الجهة موجودة في النطاق أو النطاق الفرعي (مثل adcb-secure.com أو adcb.verify-login.xyz)
        for kw in b["keywords"]:
            if not kw.isascii():
                continue
            k = kw.replace("-", "")
            if len(k) >= 4 and (k in flat or deglyph(k) in deglyph(flat)):
                hits.append((b, "keyword", kw))
                break
            if len(k) < 4 and k in full_labels:
                hits.append((b, "keyword", kw))
                break
        # 2) اسم قريب حرفياً من النطاق الرسمي (أخطاء إملائية مقصودة)
        for off in b["official"]:
            off_sld = split_domain(off)[1]
            if len(off_sld) < 4:
                continue
            for cand in {sld, deglyph(sld), sld.replace("-", "")}:
                d = levenshtein(cand, off_sld)
                if 0 < d <= (1 if len(off_sld) <= 5 else 2):
                    hits.append((b, "typo", off))
                    break
                if cand == off_sld and registered_domain(host) != off:
                    # نفس الاسم لكن بامتداد مختلف: adcb.net بدل adcb.com
                    hits.append((b, "tld_swap", off))
                    break
    # إزالة التكرار
    seen, out = set(), []
    for b, kind, detail in hits:
        key = (b["id"], kind)
        if key not in seen:
            seen.add(key)
            out.append((b, kind, detail))
    return out
