"""
التشابه البصري: مقارنة لقطة الصفحة المشبوهة بلقطات المواقع الرسمية.
صفحة تشبه موقع بنك تماماً لكن عنوانها مختلف = احتيال شبه مؤكد.
اللقطات المرجعية تُحفظ في data/brand_refs/<brand_id>.png (أنشئوها بـ: python -m monitor.build_refs)
"""
import os

from PIL import Image

REF_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "brand_refs")


def dhash(path: str, size: int = 16) -> int:
    img = Image.open(path).convert("L").resize((size + 1, size), Image.LANCZOS)
    px = list(img.getdata())
    bits = 0
    for row in range(size):
        for col in range(size):
            left = px[row * (size + 1) + col]
            right = px[row * (size + 1) + col + 1]
            bits = (bits << 1) | (left > right)
    return bits


def hamming(a: int, b: int) -> int:
    return bin(a ^ b).count("1")


def colors(path: str, k: int = 5):
    img = Image.open(path).convert("RGB").resize((64, 40))
    q = img.quantize(colors=k)
    pal = q.getpalette()[: k * 3]
    return [tuple(pal[i:i + 3]) for i in range(0, len(pal), 3)]


def _color_dist(c1, c2):
    tot = 0
    for a in c1:
        tot += min(sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5 for b in c2)
    return tot / max(len(c1), 1)


def compare(shot_path: str):
    """يرجع أقرب جهة بصرياً ونسبة التشابه (0-100)."""
    if not shot_path or not os.path.exists(shot_path) or not os.path.isdir(REF_DIR):
        return None
    h = dhash(shot_path)
    c = colors(shot_path)
    best = None
    for fn in os.listdir(REF_DIR):
        if not fn.lower().endswith(".png"):
            continue
        ref = os.path.join(REF_DIR, fn)
        d = hamming(h, dhash(ref))                 # 0..256
        layout = max(0.0, 1 - d / 128)             # تشابه التخطيط
        palette = max(0.0, 1 - _color_dist(c, colors(ref)) / 120)  # تشابه الألوان
        score = round(100 * (0.65 * layout + 0.35 * palette))
        if not best or score > best["score"]:
            best = {"brand_id": fn[:-4], "score": score, "hamming": d}
    return best
