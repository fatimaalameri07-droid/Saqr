"""فتح الرابط: تتبّع إعادة التوجيه، فك الاختصار، كشف الإخفاء (cloaking)، ولقطة الشاشة."""
import hashlib
import re
import socket
from urllib.parse import urljoin

import requests

MOBILE_UA = ("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 "
             "(KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1")
BOT_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"

META_REFRESH = re.compile(r'<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+content=["\']?\s*\d+\s*;\s*url=([^"\'>\s]+)', re.I)
JS_REDIRECT = re.compile(r'(?:window\.|document\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)["\']', re.I)


def resolve_ip(host: str):
    try:
        socket.setdefaulttimeout(4)
        return socket.gethostbyname(host)
    except Exception:
        return None


def follow(url: str, ua: str = MOBILE_UA, max_hops: int = 10, timeout: int = 10):
    """يتبع كل خطوات إعادة التوجيه (HTTP و meta refresh و JavaScript) ويسجّلها."""
    chain, html, status, final = [], "", None, url
    s = requests.Session()
    s.headers.update({"User-Agent": ua, "Accept-Language": "ar,en;q=0.8"})
    current = url
    for _ in range(max_hops):
        try:
            r = s.get(current, allow_redirects=False, timeout=timeout)
        except requests.RequestException as e:
            chain.append({"url": current, "status": None, "error": type(e).__name__})
            break
        chain.append({"url": current, "status": r.status_code})
        status = r.status_code
        if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
            loc = r.headers.get("Location")
            if not loc:
                break
            current = urljoin(current, loc)
            continue
        html = r.text[:2_000_000] if "html" in r.headers.get("Content-Type", "html") else ""
        final = current
        m = META_REFRESH.search(html) or (JS_REDIRECT.search(html) if len(html) < 5000 else None)
        if m:
            nxt = urljoin(current, m.group(1))
            if nxt != current:
                current = nxt
                continue
        break
    return {
        "final_url": final if html else current,
        "chain": chain,
        "status": status,
        "html": html,
        "html_sha256": hashlib.sha256(html.encode("utf-8", "ignore")).hexdigest() if html else None,
    }


def _title(html: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", html or "", re.I | re.S)
    return (m.group(1).strip() if m else "")[:200]


def cloaking_check(url: str, user_result: dict):
    """
    المحتالون يعرضون صفحة سليمة لأنظمة الفحص وصفحة الاحتيال للبشر.
    نفتح الرابط كمحرك بحث ونقارن بما رآه جهاز الآيفون.
    """
    try:
        bot = follow(url, ua=BOT_UA, max_hops=6, timeout=8)
    except Exception:
        return None
    u_html, b_html = user_result.get("html") or "", bot.get("html") or ""
    if not u_html:
        return None
    u_len, b_len = len(u_html), len(b_html)
    size_ratio = (min(u_len, b_len) / max(u_len, b_len)) if max(u_len, b_len) else 1
    different_final = bot["final_url"].split("?")[0] != user_result["final_url"].split("?")[0]
    different_title = _title(u_html) != _title(b_html)
    suspicious = different_final or (different_title and size_ratio < 0.5)
    return {"suspicious": suspicious, "bot_final_url": bot["final_url"], "size_ratio": round(size_ratio, 2),
            "different_title": different_title}


def screenshot(url: str, path: str, timeout_ms: int = 15000) -> bool:
    """لقطة شاشة بمتصفح حقيقي (Playwright). تحتاج: playwright install chromium"""
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(user_agent=MOBILE_UA, viewport={"width": 1280, "height": 800}, locale="ar-AE")
            page = ctx.new_page()
            page.goto(url, timeout=timeout_ms, wait_until="load")
            page.wait_for_timeout(1500)
            page.screenshot(path=path, full_page=False)
            b.close()
        return True
    except Exception:
        return False
