"""قراءة محتوى الصفحة: انتحال الجهات، نماذج سرقة البيانات، عبارات الاستعجال، والاستهداف الإماراتي."""
import json
import os
import re
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from .brands import BRANDS
from .domain import registered_domain

URGENCY = [
    # عربي
    "خلال 24 ساعة", "خلال ٢٤ ساعة", "فوراً", "فورا", "تم إيقاف", "تم ايقاف", "سيتم إيقاف", "سيتم ايقاف",
    "تم تعليق", "سيتم تعليق", "حسابك موقوف", "حسابك معلق", "تحديث بياناتك", "تحديث البيانات", "مخالفة غير مدفوعة",
    "غرامة", "آخر فرصة", "اخر فرصة", "استرداد", "جائزة", "ربحت", "مبروك", "شحنتك معلقة", "رسوم جمركية",
    "رمز التحقق", "أدخل الرمز", "ادخل الرمز", "تأكيد هويتك", "تأكيد الهوية",
    # إنجليزي
    "within 24 hours", "immediately", "suspended", "will be blocked", "has been locked", "verify your account",
    "update your details", "unpaid fine", "last chance", "refund", "you have won", "congratulations",
    "parcel is on hold", "customs fee", "confirm your identity", "enter the code", "otp",
]

CARD_FIELDS = re.compile(r"card|cvv|cvc|ccv|expir|exp_|mm/yy|pan\b|رقم البطاقة|تاريخ الانتهاء|الرمز السري", re.I)
OTP_FIELDS = re.compile(r"otp|one.?time|sms.?code|verification.?code|رمز التحقق|رمز التفعيل", re.I)
ID_FIELDS = re.compile(r"emirates.?id|eid|national.?id|passport|رقم الهوية|الهوية الإماراتية", re.I)
UAE_MARKERS = re.compile(r"\bAED\b|درهم|د\.إ|\+971|00971|الإمارات|الامارات|أبوظبي|ابوظبي|دبي|\bUAE\b|Abu Dhabi|Dubai|Emirates", re.I)


def analyze(html: str, page_url: str) -> dict:
    if not html:
        return {"empty": True}
    soup = BeautifulSoup(html, "html.parser")
    for t in soup(["script", "style", "noscript"]):
        t.extract()
    title = (soup.title.string or "").strip() if soup.title and soup.title.string else ""
    text = " ".join(soup.get_text(" ").split())[:20000]
    low = (title + " " + text).lower()
    page_reg = registered_domain(urlparse(page_url).hostname or "")

    brands = []
    for b in BRANDS:
        names = [b["name_ar"], b["name_en"]] + [k for k in b["keywords"] if len(k) >= 5]
        if any(n.lower() in low for n in names):
            brands.append(b)

    inputs = soup.find_all(["input", "select", "textarea"])
    attrs = " ".join(" ".join(str(i.get(a, "")) for a in ("name", "id", "placeholder", "type", "autocomplete", "aria-label"))
                     for i in inputs)
    labels = " ".join(l.get_text(" ") for l in soup.find_all("label"))
    field_text = attrs + " " + labels
    has_password = any((i.get("type") or "").lower() == "password" for i in inputs)
    has_card = bool(CARD_FIELDS.search(field_text))
    has_otp = bool(OTP_FIELDS.search(field_text))
    has_id = bool(ID_FIELDS.search(field_text))

    # نموذج يرسل البيانات لنطاق آخر
    ext_forms = []
    for f in soup.find_all("form"):
        act = f.get("action") or ""
        h = urlparse(act).hostname
        if h and registered_domain(h) != page_reg:
            ext_forms.append(act[:200])

    urgency = [u for u in URGENCY if u.lower() in low]
    uae_hits = len(UAE_MARKERS.findall(title + " " + text))
    arabic_ratio = len(re.findall(r"[؀-ۿ]", text)) / max(len(text), 1)

    return {
        "empty": False,
        "title": title[:200],
        "text": text,
        "brands": brands,
        "has_password": has_password,
        "has_card": has_card,
        "has_otp": has_otp,
        "has_id": has_id,
        "external_forms": ext_forms,
        "urgency": urgency[:6],
        "uae_markers": uae_hits,
        "arabic_ratio": round(arabic_ratio, 2),
        "n_inputs": len(inputs),
    }


def llm_review(title: str, text: str, url: str):
    """
    اختياري: نموذج لغوي يقرأ الصفحة بالعربية والإنجليزية ويحكم إن كانت تنتحل جهة إماراتية.
    يعمل فقط إذا كانت مكتبة anthropic مثبتة ومتغير ANTHROPIC_API_KEY موجوداً.
    """
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic
    except Exception:
        return None
    prompt = (
        "You are a fraud analyst for UAE police. Decide if this web page is a phishing/scam page that impersonates "
        "a UAE bank, government entity, telecom or delivery company, or tries to steal credentials, card data or OTPs.\n"
        f"URL: {url}\nTITLE: {title}\nTEXT (truncated): {text[:4000]}\n\n"
        'Reply with JSON only: {"is_scam": true|false, "confidence": 0-100, "impersonated": "name or null", '
        '"reason_ar": "one short sentence in Arabic"}'
    )
    try:
        client = anthropic.Anthropic()
        msg = client.messages.create(model=os.environ.get("SAQR_LLM_MODEL", "claude-haiku-5-5"), max_tokens=300,
                                     messages=[{"role": "user", "content": prompt}])
        raw = msg.content[0].text
        m = re.search(r"\{.*\}", raw, re.S)
        return json.loads(m.group(0)) if m else None
    except Exception:
        return None
