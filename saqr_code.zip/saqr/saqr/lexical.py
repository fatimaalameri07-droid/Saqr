"""خصائص الرابط النصية: تُستخدم في القواعد وفي تدريب نموذج التصنيف."""
import math
import re
from collections import Counter
from urllib.parse import urlparse

from .brands import RISKY_TLDS, SHORTENERS
from .domain import brand_similarity, is_ip, normalize_url, split_domain

SUSPICIOUS_WORDS = [
    "login", "signin", "verify", "verification", "update", "secure", "security", "account", "confirm",
    "pay", "payment", "fine", "fines", "refund", "reward", "bonus", "gift", "prize", "wallet", "otp",
    "unlock", "suspend", "blocked", "billing", "invoice", "delivery", "parcel", "customs", "tracking",
    "kyc", "auth", "support", "helpdesk", "mukhalafat", "renew", "claim",
]

FEATURE_NAMES = [
    "url_len", "host_len", "path_len", "n_dots", "n_hyphens", "n_digits_host", "digit_ratio",
    "n_subdomains", "has_ip", "is_https", "risky_tld", "n_sus_words", "entropy_host", "has_at",
    "n_params", "is_shortener", "has_punycode", "brand_keyword", "brand_typo", "n_slash", "tld_len",
]


def entropy(s: str) -> float:
    if not s:
        return 0.0
    c = Counter(s)
    return -sum(v / len(s) * math.log2(v / len(s)) for v in c.values())


def extract(url: str) -> dict:
    url = normalize_url(url)
    p = urlparse(url)
    host = (p.hostname or "").lower()
    sub, sld, suf = split_domain(host)
    low = url.lower()
    sus = [w for w in SUSPICIOUS_WORDS if re.search(r"(?<![a-z])" + w + r"(?![a-z])", low.replace("-", " ").replace("_", " ").replace(".", " ").replace("/", " "))]
    sims = brand_similarity(host) if host else []
    f = {
        "url_len": len(url),
        "host_len": len(host),
        "path_len": len(p.path or ""),
        "n_dots": host.count("."),
        "n_hyphens": host.count("-"),
        "n_digits_host": sum(ch.isdigit() for ch in host),
        "digit_ratio": (sum(ch.isdigit() for ch in host) / len(host)) if host else 0,
        "n_subdomains": len([x for x in sub.split(".") if x]) if sub else 0,
        "has_ip": int(is_ip(host)),
        "is_https": int(p.scheme == "https"),
        "risky_tld": int(suf.split(".")[-1] in RISKY_TLDS) if suf else 0,
        "n_sus_words": len(sus),
        "entropy_host": round(entropy(sld), 3),
        "has_at": int("@" in url),
        "n_params": len([x for x in (p.query or "").split("&") if x]),
        "is_shortener": int(f"{sld}.{suf}" in SHORTENERS or host in SHORTENERS),
        "has_punycode": int("xn--" in host),
        "brand_keyword": int(any(k == "keyword" for _, k, _ in sims)),
        "brand_typo": int(any(k in ("typo", "tld_swap") for _, k, _ in sims)),
        "n_slash": url.count("/") - 2,
        "tld_len": len(suf.split(".")[-1]) if suf else 0,
    }
    f["_sus_words"] = sus
    f["_brand_hits"] = sims
    f["_host"] = host
    f["_suffix"] = suf
    return f


def vector(f: dict):
    return [float(f[n]) for n in FEATURE_NAMES]


def host_vector(url: str):
    """
    خصائص النطاق فقط (بدون المسار): يُستخدم في التدريب والتنبؤ معاً.
    السبب: قوائم المواقع السليمة (Tranco) أسماء نطاقات بلا مسارات، فلو استخدمنا المسار
    سيتعلم النموذج أن "وجود مسار = احتيال" وهذا تسريب يضخّم الدقة زيفاً.
    """
    from urllib.parse import urlparse
    host = (urlparse(normalize_url(url)).hostname or "").lower()
    return vector(extract("https://" + host))
