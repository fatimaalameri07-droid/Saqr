"""
تتبّع المال: استخراج الحسابات التي يطلب المحتال التحويل إليها من صفحة الاحتيال.
أرقام IBAN الإماراتية، أرقام الهواتف الإماراتية، ومحافظ العملات الرقمية.
"""
import re

IBAN_AE = re.compile(r"\bAE\s?\d{2}(?:[\s-]?\d){19}\b", re.I)
PHONE_AE = re.compile(r"(?<!\d)(?:\+971|00971|0)[\s-]?(?:5[0-9]|[2-79])(?:[\s-]?\d){7}(?!\d)")
BTC = re.compile(r"\b(?:bc1[a-z0-9]{25,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b")
ETH = re.compile(r"\b0x[a-fA-F0-9]{40}\b")
TRON = re.compile(r"\bT[1-9A-HJ-NP-Za-km-z]{33}\b")
WHATSAPP = re.compile(r"(?:wa\.me|api\.whatsapp\.com/send\?phone=)/?\+?(\d{9,15})", re.I)
TELEGRAM = re.compile(r"(?:t\.me|telegram\.me)/([A-Za-z0-9_]{4,32})", re.I)

# تحويل الأرقام العربية الهندية إلى أرقام لاتينية
_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def valid_iban(iban: str) -> bool:
    s = re.sub(r"[\s-]", "", iban).upper()
    if not re.fullmatch(r"AE\d{21}", s):
        return False
    rearr = s[4:] + s[:4]
    num = "".join(str(int(c, 36)) for c in rearr)
    return int(num) % 97 == 1


def normalize_phone(p: str) -> str:
    d = re.sub(r"\D", "", p)
    if d.startswith("00971"):
        d = d[5:]
    elif d.startswith("971"):
        d = d[3:]
    elif d.startswith("0"):
        d = d[1:]
    return "+971" + d


def extract(text: str) -> dict:
    text = (text or "").translate(_AR_DIGITS)
    ibans = sorted({re.sub(r"[\s-]", "", m.group(0)).upper() for m in IBAN_AE.finditer(text) if valid_iban(m.group(0))})
    phones = sorted({normalize_phone(m.group(0)) for m in PHONE_AE.finditer(text)})
    phones += sorted({"+" + m.group(1) for m in WHATSAPP.finditer(text)} - set(phones))
    wallets = sorted({m.group(0) for r in (ETH, TRON) for m in r.finditer(text)} |
                     {m.group(0) for m in BTC.finditer(text) if len(m.group(0)) >= 26})
    telegram = sorted({m.group(1) for m in TELEGRAM.finditer(text)})
    return {"ibans": ibans, "phones": phones, "wallets": wallets, "telegram": telegram}


def has_any(ind: dict) -> bool:
    return any(ind.get(k) for k in ("ibans", "phones", "wallets", "telegram"))
