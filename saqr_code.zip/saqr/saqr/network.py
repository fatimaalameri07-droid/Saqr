"""
ربط مواقع الاحتيال كشبكة: المواقع التي تشترك في حساب بنكي أو رقم هاتف أو محفظة أو عنوان IP
أو مسجِّل وتاريخ تسجيل متقارب، غالباً تعود لنفس العصابة.
"""
import networkx as nx


def build(scans, min_score: int = 40, include_ip: bool = False):
    """include_ip معطّل افتراضياً: عناوين IP لشبكات مثل Cloudflare مشتركة بين آلاف المواقع."""
    G = nx.Graph()
    for s in scans:
        if s.get("score", 0) < min_score or s.get("whitelisted"):
            continue
        site = "site:" + (s.get("registered_domain") or s.get("domain"))
        G.add_node(site, kind="site", score=s.get("score"), url=s.get("final_url"))
        ind = s.get("indicators") or {}
        for iban in ind.get("ibans", []):
            G.add_edge(site, "iban:" + iban)
        for ph in ind.get("phones", []):
            G.add_edge(site, "phone:" + ph)
        for w in ind.get("wallets", []):
            G.add_edge(site, "wallet:" + w)
        for t in ind.get("telegram", []):
            G.add_edge(site, "telegram:" + t)
        if include_ip and s.get("ip"):
            G.add_edge(site, "ip:" + s["ip"])
    for n in G.nodes:
        if ":" in n and not n.startswith("site:"):
            G.nodes[n]["kind"] = n.split(":")[0]
    return G


def clusters(G):
    """يرجع الشبكات التي تضم موقعين أو أكثر، مرتبة بالحجم."""
    out = []
    for comp in nx.connected_components(G):
        sites = sorted(n[5:] for n in comp if n.startswith("site:"))
        if len(sites) < 2:
            continue
        links = sorted(n for n in comp if not n.startswith("site:"))
        out.append({
            "sites": sites,
            "ibans": [x[5:] for x in links if x.startswith("iban:")],
            "phones": [x[6:] for x in links if x.startswith("phone:")],
            "wallets": [x[7:] for x in links if x.startswith("wallet:")],
            "ips": [x[3:] for x in links if x.startswith("ip:")],
            "telegram": [x[9:] for x in links if x.startswith("telegram:")],
        })
    return sorted(out, key=lambda c: -len(c["sites"]))


def bank_freeze_list(scans, min_score: int = 70):
    """قائمة الحسابات المرتبطة بمواقع عالية الخطورة لإرسالها للبنوك (تجميد / تعليق التحويلات إليها)."""
    acc = {}
    for s in scans:
        if s.get("score", 0) < min_score:
            continue
        for iban in (s.get("indicators") or {}).get("ibans", []):
            acc.setdefault(iban, {"iban": iban, "bank_code": iban[4:7], "sites": set(), "max_score": 0})
            acc[iban]["sites"].add(s.get("registered_domain"))
            acc[iban]["max_score"] = max(acc[iban]["max_score"], s.get("score", 0))
    return [{**v, "sites": sorted(v["sites"])} for v in sorted(acc.values(), key=lambda x: -x["max_score"])]
