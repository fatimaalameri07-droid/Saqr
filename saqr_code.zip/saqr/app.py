"""
لوحة صقر للشرطة.  تشغيل:  streamlit run app.py
"""
import json
import os

import pandas as pd
import streamlit as st

from monitor.sms_ingest import extract_urls
from saqr import engine, network, report, store

st.set_page_config(page_title="صقر — لوحة الشرطة", page_icon="🦅", layout="wide")
st.markdown("""
<style>
html, body, [class*="css"], .stMarkdown, .stTextInput, .stTextArea, .stButton, .stTabs { direction: rtl; text-align: right; }
.stTextInput input, .stTextArea textarea { direction: ltr; text-align: left; }
.badge-high{background:#B4232A;color:#fff;padding:4px 14px;border-radius:20px;font-weight:700}
.badge-medium{background:#B76E00;color:#fff;padding:4px 14px;border-radius:20px;font-weight:700}
.badge-low,.badge-safe{background:#2F6B3A;color:#fff;padding:4px 14px;border-radius:20px;font-weight:700}
.reason{padding:6px 0;border-bottom:1px solid #eee}
.layer{color:#8A5A12;font-size:13px;font-weight:700}
</style>""", unsafe_allow_html=True)

st.title("🦅 صقر")
st.caption("كشف روابط الاحتيال التي تستهدف الإمارات وتتبّع الحسابات التي تستقبل الأموال")

with st.sidebar:
    st.header("الإعدادات")
    fetch = st.toggle("فتح الرابط وتحليل الصفحة", value=True)
    deep = st.toggle("فحص عميق (WHOIS، لقطة شاشة، كشف الإخفاء)", value=True)
    m = "model/metrics.json"
    if os.path.exists(m):
        mt = json.load(open(m, encoding="utf-8"))
        st.subheader("دقة النموذج")
        st.metric("الدقة (Precision)", f"{mt['precision']}%")
        st.metric("الاستدعاء (Recall)", f"{mt['recall']}%")
        st.metric("الإيجابيات الخاطئة", f"{mt['false_positive_rate']}%")
    else:
        st.info("لم يُدرَّب النموذج بعد: python train.py\nالمحرك يعمل بالقواعد حالياً.")


def show_result(r):
    c1, c2 = st.columns([1, 2])
    with c1:
        st.markdown(f"<div style='font-size:72px;font-weight:800;line-height:1'>{r['score']}<span style='font-size:28px'>/100</span></div>",
                    unsafe_allow_html=True)
        st.markdown(f"<span class='badge-{r['level']}'>{r['level_ar']}</span>", unsafe_allow_html=True)
        if r.get("impersonated"):
            st.write("**الجهة المنتحَلة:** " + "، ".join(r["impersonated"]))
        st.write("**يستهدف الإمارات:** " + ("نعم" if r.get("uae_targeted") else "غير واضح"))
        st.code(r.get("final_url", ""), language=None)
    with c2:
        st.subheader("أسباب الحكم")
        for x in r.get("reasons", []):
            st.markdown(f"<div class='reason'><span class='layer'>{x['layer']}</span> · {x['text']} "
                        f"<span style='color:#999'>(+{x['points']})</span></div>", unsafe_allow_html=True)
    ind = r.get("indicators") or {}
    if any(ind.get(k) for k in ("ibans", "phones", "wallets", "telegram")):
        st.subheader("💰 تتبّع المال")
        st.json({k: v for k, v in ind.items() if v})
    with st.expander("الأدلة التقنية"):
        if r.get("screenshot") and os.path.exists(r["screenshot"]):
            st.image(r["screenshot"])
        st.write("**سلسلة إعادة التوجيه**")
        for h in r.get("redirect_chain", []):
            st.text(f"{h.get('status')}  {h.get('url')}")
        if r.get("whois"):
            st.json(r["whois"])
        if r.get("cloaking"):
            st.json(r["cloaking"])
    if not r.get("whitelisted") and r["score"] >= 40:
        b1, b2 = st.columns(2)
        b1.download_button("📄 تقرير الأدلة", report.evidence_html(r), file_name=f"saqr_{r['id']}.html", mime="text/html")
        b2.download_button("✉️ طلب الإزالة", report.takedown_text(r), file_name=f"takedown_{r['id']}.txt")


t1, t2, t3, t4, t5 = st.tabs(["🔍 فحص رابط", "📱 الرسائل النصية", "📡 الرصد المبكر", "🕸️ شبكات الاحتيال", "🏦 قائمة البنوك"])

with t1:
    url = st.text_input("الرابط", placeholder="https://...")
    if st.button("افحص", type="primary") and url:
        with st.spinner("صقر يفحص الرابط..."):
            r = engine.scan(url, source="manual", fetch=fetch, deep=deep)
            store.save(r)
        show_result(r)

with t2:
    st.write("محاكاة لما يمرّره جدار حماية الرسائل عند شركة الاتصالات: **الرابط فقط**، دون نص الرسالة أو بيانات المرسل.")
    default = ""
    if os.path.exists("data/sample_sms.txt"):
        default = "\n".join(l for l in open("data/sample_sms.txt", encoding="utf-8").read().splitlines() if l and not l.startswith("#"))
    msgs = st.text_area("رسائل واردة (رسالة في كل سطر)", value=default, height=220)
    if st.button("مرّر الرسائل عبر صقر", type="primary"):
        rows = []
        bar = st.progress(0.0)
        lines = [l for l in msgs.splitlines() if l.strip()]
        for i, msg in enumerate(lines):
            for u in extract_urls(msg):
                r = engine.scan(u, source="sms", fetch=fetch, deep=False)
                store.save(r)
                action = "⛔ حجب + إرسال للشرطة" if r["score"] >= 70 else ("⚠️ تحذير المستلم" if r["score"] >= 40 else "✅ تمرير")
                rows.append({"الإجراء": action, "الدرجة": r["score"], "الحكم": r["level_ar"],
                             "الجهة المنتحلة": "، ".join(r.get("impersonated") or []), "الرابط": u})
            bar.progress((i + 1) / len(lines))
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

with t3:
    st.write("التنبيهات الواردة من الرصد المبكر: النطاقات المشابهة وسجلات الشهادات. شغّلوا في نافذة أخرى:")
    st.code("python -m monitor.typosquat --quick-tlds --scan\npython -m monitor.ct_monitor --days 3 --scan", language="bash")
    data = [s for s in store.all_scans(min_score=40) if s.get("source") in ("typosquat", "ct-log", "ct-live")]
    if data:
        st.dataframe(pd.DataFrame([{"الدرجة": s["score"], "الحكم": s["level_ar"], "النطاق": s["domain"],
                                    "المصدر": s["source"], "الوقت": s["scanned_at"],
                                    "الجهة": "، ".join(s.get("impersonated") or [])} for s in data]),
                     use_container_width=True, hide_index=True)
    else:
        st.info("لا توجد تنبيهات بعد.")

with t4:
    st.write("مواقع تشترك في حساب بنكي أو رقم هاتف أو محفظة = غالباً نفس العصابة.")
    G = network.build(store.all_scans())
    cl = network.clusters(G)
    if not cl:
        st.info("لم تُكتشف شبكات بعد. تظهر عندما يشترك موقعان أو أكثر في مؤشر مالي.")
    for i, c in enumerate(cl, 1):
        with st.container(border=True):
            st.markdown(f"**شبكة {i}: {len(c['sites'])} مواقع**")
            st.write("المواقع: " + "، ".join(c["sites"]))
            for k, lbl in (("ibans", "حسابات"), ("phones", "هواتف"), ("wallets", "محافظ"), ("telegram", "تيليجرام")):
                if c[k]:
                    st.write(f"{lbl}: " + "، ".join(c[k]))

with t5:
    st.write("حسابات IBAN المستخرجة من مواقع عالية الخطورة، لإرسالها للبنوك لتجميدها وتعليق التحويلات إليها.")
    fl = network.bank_freeze_list(store.all_scans())
    if fl:
        df = pd.DataFrame([{"IBAN": x["iban"], "رمز البنك": x["bank_code"], "أعلى درجة": x["max_score"],
                            "المواقع": "، ".join(x["sites"])} for x in fl])
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.download_button("⬇️ تصدير للبنوك (CSV)", df.to_csv(index=False).encode("utf-8-sig"), "freeze_list.csv")
    else:
        st.info("لا توجد حسابات بعد.")
