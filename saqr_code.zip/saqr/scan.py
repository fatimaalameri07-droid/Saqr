"""
فحص سريع من سطر الأوامر.
  python scan.py https://example.com
  python scan.py adcb-secure.xyz --offline      (تحليل العنوان فقط بدون إنترنت)
  python scan.py URL --report                   (يحفظ تقرير الأدلة وطلب الإزالة)
"""
import argparse
import json
import os

from saqr import engine, report, store

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("urls", nargs="+")
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--fast", action="store_true", help="بدون لقطة شاشة وبيانات النطاق")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--report", action="store_true")
    a = ap.parse_args()
    for u in a.urls:
        r = engine.scan(u, fetch=not a.offline, deep=not a.fast)
        store.save(r)
        if a.json:
            print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
            continue
        print(f"\n{r['final_url']}\n  {r['score']}/100 — {r['level_ar']}")
        for x in r["reasons"]:
            print(f"   +{x['points']:<3} [{x['layer']}] {x['text']}")
        ind = r.get("indicators") or {}
        for k in ("ibans", "phones", "wallets"):
            if ind.get(k):
                print(f"   {k}: {', '.join(ind[k])}")
        if a.report:
            os.makedirs("evidence/reports", exist_ok=True)
            p = f"evidence/reports/{r['id']}"
            open(p + ".html", "w", encoding="utf-8").write(report.evidence_html(r))
            open(p + "_takedown.txt", "w", encoding="utf-8").write(report.takedown_text(r))
            print(f"   التقرير: {p}.html  |  طلب الإزالة: {p}_takedown.txt")
