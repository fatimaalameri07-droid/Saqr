"""
قناة الرسائل النصية: محاكاة لما يرسله جدار حماية الرسائل عند شركة الاتصالات.
النظام يستخرج الرابط فقط من الرسالة، ولا يخزّن نصها ولا رقم المرسل أو المستلم.

تشغيل:  python -m monitor.sms_ingest data/sample_sms.txt
"""
import re
import sys

URL_RE = re.compile(
    r"(?:https?://|hxxps?://|www\.)\S+|"
    r"\b[a-z0-9][a-z0-9-]{1,62}(?:\.[a-z0-9-]{2,63})*\.(?:com|net|org|info|xyz|top|online|site|shop|live|ae|co|me|cc|app|vip|link|click|icu|buzz|cfd|sbs)\b(?:/\S*)?",
    re.I)


def extract_urls(message: str):
    urls = []
    for m in URL_RE.finditer(message or ""):
        u = m.group(0).rstrip(".,،)»\"'")
        if "@" in u.split("/")[0]:
            continue  # بريد إلكتروني وليس رابطاً
        urls.append(u)
    return list(dict.fromkeys(urls))


def process(messages, fetch=True, deep=False, save=True):
    from saqr import engine, store
    results = []
    for msg in messages:
        for u in extract_urls(msg):
            r = engine.scan(u, source="sms", fetch=fetch, deep=deep)
            if save:
                store.save(r)
            action = "حجب الرسالة + إرسال للشرطة" if r["score"] >= 70 else ("تحذير المستلم" if r["score"] >= 40 else "تمرير")
            results.append({"url": u, "score": r["score"], "level": r["level_ar"], "action": action, "result": r})
    return results


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "data/sample_sms.txt"
    offline = "--offline" in sys.argv
    with open(path, encoding="utf-8") as f:
        msgs = [l.strip() for l in f if l.strip() and not l.startswith("#")]
    for x in process(msgs, fetch=not offline):
        print(f"{x['score']:>3}/100  {x['level']:14s} {x['action']:28s} {x['url']}")
