"""
الرصد المبكر 1: توليد الأسماء المشابهة لنطاقات الجهات الإماراتية والتحقق أيها مسجَّل ويعمل فعلاً.
يلتقط مواقع الاحتيال قبل أن تُرسل روابطها للناس.

تشغيل:  python -m monitor.typosquat --brand adcb --scan
"""
import argparse
import concurrent.futures as cf
import socket

from saqr.brands import BRANDS
from saqr.domain import split_domain

KEYBOARD = {
    "q": "wa", "w": "qes", "e": "wrd", "r": "etf", "t": "ryg", "y": "tuh", "u": "yij", "i": "uok", "o": "ipl",
    "p": "o", "a": "qsz", "s": "awdz", "d": "sefx", "f": "drgc", "g": "fthv", "h": "gyjb", "j": "hukn",
    "k": "jilm", "l": "ko", "z": "asx", "x": "zsdc", "c": "xdfv", "v": "cfgb", "b": "vghn", "n": "bhjm", "m": "njk",
}
GLYPHS = {"o": "0", "l": "1", "i": "1", "e": "3", "a": "4", "s": "5", "b": "8", "m": "rn", "w": "vv", "d": "cl"}
WORDS = ["pay", "secure", "login", "online", "uae", "ae", "app", "verify", "update", "portal", "services",
         "fines", "refund", "support", "my", "e"]
TLDS = ["com", "net", "org", "info", "co", "ae", "xyz", "top", "online", "site", "shop", "live", "app", "cc", "me", "vip"]


def variants(name: str):
    out = set()
    for i in range(len(name)):
        out.add(name[:i] + name[i + 1:])                       # حذف حرف
        out.add(name[:i] + name[i] + name[i:])                 # تكرار حرف
        if i < len(name) - 1:
            out.add(name[:i] + name[i + 1] + name[i] + name[i + 2:])  # تبديل حرفين
        for k in KEYBOARD.get(name[i], ""):
            out.add(name[:i] + k + name[i + 1:])               # حرف مجاور في لوحة المفاتيح
        if name[i] in GLYPHS:
            out.add(name[:i] + GLYPHS[name[i]] + name[i + 1:])  # حرف مشابه بصرياً
        if 0 < i < len(name):
            out.add(name[:i] + "-" + name[i:])                 # شرطة
    for w in WORDS:
        out |= {f"{name}-{w}", f"{w}-{name}", f"{name}{w}", f"{w}{name}"}
    out.discard(name)
    return {v for v in out if len(v) >= 3 and not v.startswith("-") and not v.endswith("-")}


def candidates(official: str, tlds=TLDS):
    sub, sld, suf = split_domain(official)
    names = variants(sld) | {sld}
    out = set()
    for n in names:
        for t in tlds:
            d = f"{n}.{t}"
            if d != official:
                out.add(d)
    return sorted(out)


def resolves(domain: str):
    try:
        return domain, socket.gethostbyname(domain)
    except Exception:
        return domain, None


def find_live(official: str, workers: int = 64, tlds=TLDS):
    socket.setdefaulttimeout(3)
    cands = candidates(official, tlds)
    live = []
    with cf.ThreadPoolExecutor(workers) as ex:
        for d, ip in ex.map(resolves, cands):
            if ip:
                live.append({"domain": d, "ip": ip, "lookalike_of": official})
    return live, len(cands)


def main():
    ap = argparse.ArgumentParser(description="رصد النطاقات المشابهة للجهات الإماراتية")
    ap.add_argument("--brand", help="معرّف الجهة مثل adcb أو uaepass (بدونه: كل الجهات)")
    ap.add_argument("--scan", action="store_true", help="فحص كل نطاق حي بمحرك صقر وحفظه")
    ap.add_argument("--quick-tlds", action="store_true", help="امتدادات قليلة فقط (أسرع للعرض)")
    a = ap.parse_args()
    tlds = ["com", "net", "xyz", "top", "online", "ae"] if a.quick_tlds else TLDS
    brands = [b for b in BRANDS if not a.brand or b["id"] == a.brand]
    for b in brands:
        for off in b["official"]:
            live, n = find_live(off, tlds=tlds)
            print(f"\n[{b['name_en']}] {off}: فُحص {n} اسم مشابه، الحي منها: {len(live)}")
            for x in live:
                line = f"  {x['domain']:35s} {x['ip']}"
                if a.scan:
                    from saqr import engine, store
                    r = engine.scan(x["domain"], source="typosquat")
                    store.save(r)
                    line += f"  ← {r['score']}/100 {r['level_ar']}"
                print(line)


if __name__ == "__main__":
    main()
