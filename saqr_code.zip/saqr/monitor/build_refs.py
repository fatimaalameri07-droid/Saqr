"""
ينشئ اللقطات المرجعية للمواقع الرسمية (للتشابه البصري). يُشغَّل مرة واحدة قبل العرض.
تشغيل:  python -m monitor.build_refs
يحتاج:  pip install playwright && playwright install chromium
"""
import os

from saqr.brands import BRANDS
from saqr.fetch import screenshot
from saqr.visual import REF_DIR

if __name__ == "__main__":
    os.makedirs(REF_DIR, exist_ok=True)
    for b in BRANDS:
        if not b["official"]:
            continue
        url = "https://" + b["official"][0]
        path = os.path.join(REF_DIR, f"{b['id']}.png")
        ok = screenshot(url, path)
        print(("✓ " if ok else "✗ ") + f"{b['name_en']:30s} {url}")
