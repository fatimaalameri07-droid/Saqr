"""
الرصد المبكر 2: سجلات شهادات SSL (Certificate Transparency).
كل موقع يحصل على شهادة HTTPS يظهر في هذه السجلات العامة خلال دقائق، قبل أن يبدأ المحتال بإرسال الرابط.

وضعان:
  python -m monitor.ct_monitor --live            بث لحظي (يحتاج: pip install certstream)
  python -m monitor.ct_monitor --days 3 --scan   بحث في crt.sh عن شهادات آخر 3 أيام بأسماء الجهات الإماراتية
"""
import argparse
import time
from datetime import datetime, timedelta, timezone

import requests

from saqr.brands import BRANDS
from saqr.domain import brand_similarity, registered_domain, whitelist_match


def watch_terms():
    terms = set()
    for b in BRANDS:
        for k in b["keywords"]:
            if k.isascii() and len(k.replace("-", "")) >= 5:
                terms.add(k.replace("-", ""))
        for off in b["official"]:
            sld = off.split(".")[0]
            if len(sld) >= 4:
                terms.add(sld)
    return sorted(terms)


def is_candidate(domain: str):
    domain = domain.lstrip("*.").lower()
    if whitelist_match(domain):
        return None
    hits = brand_similarity(domain)
    return hits or None


def crtsh(term: str, days: int):
    since = datetime.now(timezone.utc) - timedelta(days=days)
    try:
        r = requests.get("https://crt.sh/", params={"q": f"%{term}%", "output": "json"}, timeout=60)
        rows = r.json() if r.status_code == 200 else []
    except Exception:
        return []
    out = set()
    for row in rows:
        try:
            nb = datetime.fromisoformat(row["not_before"]).replace(tzinfo=timezone.utc)
        except Exception:
            continue
        if nb < since:
            continue
        for name in row.get("name_value", "").split("\n"):
            name = name.strip().lstrip("*.").lower()
            if name and is_candidate(name):
                out.add(name)
    return sorted(out)


def run_history(days: int, scan: bool):
    seen = set()
    for t in watch_terms():
        found = crtsh(t, days)
        new = [d for d in found if registered_domain(d) not in seen]
        if new:
            print(f"\n[{t}] شهادات جديدة مشبوهة: {len(new)}")
        for d in new:
            seen.add(registered_domain(d))
            line = f"  {d}"
            if scan:
                from saqr import engine, store
                r = engine.scan(d, source="ct-log")
                store.save(r)
                line += f"  ← {r['score']}/100 {r['level_ar']}"
            print(line)
        time.sleep(2)  # احترام حدود crt.sh


def run_live(scan: bool):
    try:
        import certstream
    except ImportError:
        print("ثبّت المكتبة أولاً: pip install certstream")
        return

    def cb(msg, ctx):
        if msg.get("message_type") != "certificate_update":
            return
        for d in msg["data"]["leaf_cert"]["all_domains"]:
            hits = is_candidate(d)
            if hits:
                line = f"[{datetime.now():%H:%M:%S}] {d}  ← يشبه {hits[0][0]['name_en']}"
                if scan:
                    from saqr import engine, store
                    r = engine.scan(d, source="ct-live")
                    store.save(r)
                    line += f"  {r['score']}/100"
                print(line, flush=True)

    print("يراقب سجلات الشهادات لحظياً... (Ctrl+C للإيقاف)")
    certstream.listen_for_events(cb, url="wss://certstream.calidog.io/")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--days", type=int, default=3)
    ap.add_argument("--scan", action="store_true")
    a = ap.parse_args()
    run_live(a.scan) if a.live else run_history(a.days, a.scan)
