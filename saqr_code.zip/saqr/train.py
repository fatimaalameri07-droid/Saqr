"""
تدريب نموذج التصنيف وقياس دقته (لشريحة "الدقة" في العرض).

البيانات (مجانية، حمّلوها وضعوها في مجلد data):
  data/phish.csv   روابط احتيال. من OpenPhish (https://openphish.com/feed.txt) أو PhishTank. عمود url أو رابط في كل سطر.
  data/legit.csv   روابط سليمة. قائمة Tranco (https://tranco-list.eu) بصيغة rank,domain
  data/uae_phish.csv (اختياري) روابط احتيال إماراتية جمعتموها من البلاغات. تُضاعف أهميتها في التدريب.

تشغيل:  python train.py
الناتج: model/model.joblib  و  model/metrics.json
"""
import argparse
import csv
import json
import os
import random

from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split

from saqr import lexical
from saqr.domain import whitelist_match

try:
    from xgboost import XGBClassifier
except Exception:
    XGBClassifier = None

import joblib


def read_urls(path, limit=None):
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as f:
        first = f.readline()
        f.seek(0)
        if "url" in first.lower() and "," in first:
            rows = csv.DictReader(f)
            col = next(c for c in rows.fieldnames if c.lower() == "url")
            out = [r[col] for r in rows if r.get(col)]
        else:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                out.append(line.split(",")[-1])
    random.shuffle(out)
    return out[:limit] if limit else out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max", type=int, default=20000, help="أقصى عدد لكل فئة")
    a = ap.parse_args()
    random.seed(42)

    phish = read_urls("data/phish.csv", a.max)
    uae = read_urls("data/uae_phish.csv")
    legit = read_urls("data/legit.csv", a.max)
    if not phish or not legit:
        print("ضعوا data/phish.csv و data/legit.csv أولاً (انظر التعليمات أعلى الملف).")
        return

    X, y, w = [], [], []
    for u in phish:
        X.append(lexical.host_vector(u)); y.append(1); w.append(1.0)
    for u in uae:
        X.append(lexical.host_vector(u)); y.append(1); w.append(3.0)
    for u in legit:
        X.append(lexical.host_vector(u)); y.append(0); w.append(1.0)

    Xtr, Xte, ytr, yte, wtr, _ = train_test_split(X, y, w, test_size=0.2, stratify=y, random_state=42)
    if XGBClassifier:
        model = XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1, eval_metric="logloss")
        name = "XGBoost"
    else:
        model = GradientBoostingClassifier(n_estimators=300, max_depth=4)
        name = "GradientBoosting"
    model.fit(Xtr, ytr, sample_weight=wtr)
    pred = model.predict(Xte)
    tn, fp, fn, tp = confusion_matrix(yte, pred).ravel()
    m = {
        "model": name,
        "train_size": len(Xtr), "test_size": len(Xte),
        "phish_samples": len(phish) + len(uae), "legit_samples": len(legit),
        "accuracy": round(accuracy_score(yte, pred) * 100, 2),
        "precision": round(precision_score(yte, pred) * 100, 2),
        "recall": round(recall_score(yte, pred) * 100, 2),
        "f1": round(f1_score(yte, pred) * 100, 2),
        "false_positive_rate": round(fp / (fp + tn) * 100, 2),
        "confusion": {"tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)},
    }
    # اختبار القائمة البيضاء: هل يُصنَّف أي موقع رسمي إماراتي كاحتيال؟
    from saqr.brands import all_official_domains
    m["official_sites_flagged"] = [d for d in all_official_domains() if not whitelist_match(d)]

    os.makedirs("model", exist_ok=True)
    joblib.dump(model, "model/model.joblib")
    with open("model/metrics.json", "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
    print(json.dumps(m, ensure_ascii=False, indent=2))
    print("\nضعوا هذه الأرقام في شريحة الدقة: الدقة = precision، الاستدعاء = recall، الإيجابيات الخاطئة = false_positive_rate")


if __name__ == "__main__":
    main()
